var gl;

var RLoc;
var SLoc;
var TLoc;

window.onload = function init(){
    var canvas = document.getElementById("canvas_id");
    gl = WebGLUtils.setupWebGL(canvas);
    if(!gl){
        console.log('WebGL not supported, falling back on experimental-webgl');
        gl = canvas.getContext('webgl');
    }
    if(!gl){
        alert('Your browser does not support WebGL');
    }
    
    //  Configure WebGL
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    gl.enable(gl.DEPTH_TEST);

    var program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);

    // Prepare objects
    sphere = new Sphere(0, 0.5, 10);
    cone = new Cone(sphere.startId+sphere.count, 0.5, 1, 10);
    pyramid = new Pyramid(cone.startId+cone.count, 1, 1, 1);

    //Load data into GPU
    var verticesId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, verticesId);

    gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW);
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);


    gl.enableVertexAttribArray(vPosition);
    var colorsId = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, colorsId);

    gl.bufferData(gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW);
    var vColor = gl.getAttribLocation(program, "vColor");
    gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);

    gl.enableVertexAttribArray(vColor);
    RLoc = gl.getUniformLocation(program, "R");
    SLoc = gl.getUniformLocation(program, "S");
    TLoc = gl.getUniformLocation(program, "T");

    //menu
    var TLR = document.getElementById("TLR");
    var TUD = document.getElementById("TUD");
    var TFB = document.getElementById("TFB");

    var SX = document.getElementById("SX");
    var SY = document.getElementById("SY");
    var SZ = document.getElementById("SZ");

    var RX = document.getElementById("RX");
    var RY = document.getElementById("RY");
    var RZ = document.getElementById("RZ");
    var R = mat4();

    var objMenu = document.getElementById("objMenu");
    var visibleChkB = document.getElementById("visibleChkB");

    var render = function(){
        gl.clear(gl.COLOR_BUFFER_BIT);

        if(+SX.value == 0) SX.value = "0.5";
        if(+SY.value == 0) SY.value = "0.5";
        if(+SZ.value == 0) SZ.value = "0.5";

        R = mult(rotateZ(+RZ.value), rotateY(+RY.value));
        R = mult(R, rotateX(+RX.value));
        
        switch(objMenu.options[objMenu.selectedIndex].value){
            case 'sphere':
                sphere.T = translate(+TLR.value, +TUD.value, +TFB.value);
                if(visibleChkB.checked == true){
                    sphere.S = scalem(+SX.value, +SY.value, +SZ.value);
                } else {
                    sphere.S = scalem(0.0, 0.0, 0.0);
                }
                sphere.R = R;
                break;

            case 'cone':
                cone.T = translate(+TLR.value, +TUD.value, +TFB.value);
                if(visibleChkB.checked == true){
                    cone.S = scalem(+SX.value, +SY.value, +SZ.value);
                } else {
                    cone.S = scalem(0.0, 0.0, 0.0);
                }
                cone.R = R;
                break;

            case 'pyramid':
                pyramid.T = translate(+TLR.value, +TUD.value, +TFB.value);
                if(visibleChkB.checked == true){
                    pyramid.S = scalem(+SX.value, +SY.value, +SZ.value);
                } else {
                    pyramid.S = scalem(0.0, 0.0, 0.0);
                }
                pyramid.R = R;
                break;
        }   

        sphere.draw();
        cone.draw();
        pyramid.draw();

        window.requestAnimFrame(render);
    };

    render();
};