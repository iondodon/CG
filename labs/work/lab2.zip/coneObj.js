class Cone {
    constructor(startId, radius, height, delta){
        this.startId = startId;
        this.count = 0;

        this.radius = radius;
        this.height = height;
        this.delta = delta;

        this.R = rotate(30, [1, 0, 1]);
        this.S = scalem(0.3, 0.3, 1.0);
        this.T = translate(-0.8, 0.3, 0.0);

        this.calculateCone();
    }
    
    /**
     * @return {number}
     */
    X(phi){
        let radius = this.radius;
        return radius * Math.cos(radians(phi));
    }

    /**
     * @return {number}
     */
    Z(phi){
        let radius = this.radius;
        return radius * Math.sin(radians(phi));
    }

    calculateCone(){
        let delta = this.delta;
        
        for(let phi = 0; phi < 360; phi += delta){
            vertices.push(vec4( 0, this.height, 0, 1));
            colors.push(vec4(1, 0, 0, 1));

            vertices.push(vec4( this.X(phi), 0, this.Z(phi), 1));
            colors.push(vec4(0, 1, 0, 1));

            vertices.push(vec4( this.X(phi+delta), 0, this.Z(phi+delta), 1));
            colors.push(vec4(0, 1, 0, 1));

            vertices.push(vec4( this.X(phi), 0, this.Z(phi), 1));
            colors.push(vec4(0, 1, 0, 1));

            vertices.push(vec4( this.X(phi+delta), 0, this.Z(phi+delta), 1));
            colors.push(vec4(0, 1, 0, 1));

            vertices.push(vec4( 0, 0, 0, 1));
            colors.push(vec4(0, 0, 1, 1));

            this.count += 6;
        }
    }

    draw(){
        gl.uniformMatrix4fv(RLoc, false, flatten(this.R));
        gl.uniformMatrix4fv(SLoc, false, flatten(this.S));
        gl.uniformMatrix4fv(TLoc, false, flatten(this.T));
        gl.drawArrays(gl.TRIANGLES, this.startId, this.count);
    }
}