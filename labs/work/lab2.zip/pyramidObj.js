class Pyramid  {
    constructor(startId, leng, width, height){
        this.startId = startId;
        this.count = 0;

        this.leng = leng;
        this.width = width;
        this.height = height;

        this.R = rotate(20, [1, 1, 0]);
        this.S = scalem(0.3, 0.3, 1.0);
        this.T = translate(-1.0, -0.1, 0.0);

        this.calculatePyramid();
    }

    calculatePyramid(){
        let leng = this.leng;
        let width = this.width;
        let height = this.height;

        //front
        vertices.push( vec4(leng/2, height, width/2, 1) );
        colors.push( vec4(1, 0, 0, 1) );

        vertices.push( vec4(0, 0, width, 1) );
        colors.push( vec4(1, 0, 0, 1) );
        
        vertices.push( vec4(leng, 0, width, 1) );
        colors.push( vec4(1, 0, 0, 1) );

        //left
        vertices.push( vec4(leng/2, height, width/2, 1) );
        colors.push( vec4(1, 1, 0, 1) );

        vertices.push( vec4(0, 0, width, 1) );
        colors.push( vec4(1, 1, 0, 1) );

        vertices.push( vec4(0, 0, 0, 1) );
        colors.push( vec4(1, 1, 0, 1) );

        //back
        vertices.push( vec4(leng/2, height, width/2, 1) );
        colors.push( vec4(1, 0, 1, 1) );

        vertices.push( vec4(0, 0, 0, 1) );
        colors.push( vec4(1, 0, 0, 1) );

        vertices.push( vec4(leng, 0, 0, 1) );
        colors.push( vec4(1, 0, 1, 1) );

        //right
        vertices.push( vec4(leng/2, height, width/2, 1) );
        colors.push( vec4(0, 1, 0, 1) );

        vertices.push( vec4(leng, 0, 0, 1) );
        colors.push( vec4(0, 1, 0, 1) );

        vertices.push( vec4(leng, 0, width, 1) );
        colors.push( vec4(0, 1, 0, 1) );

        //bottom
        vertices.push( vec4(0, 0, width, 1) );
        colors.push( vec4(0, 0, 1, 1) );

        vertices.push( vec4(0, 0, 0, 1) );
        colors.push( vec4(0, 0, 1, 1) );

        vertices.push( vec4(leng, 0, width, 1) );
        colors.push( vec4(0, 0, 1, 1) );

        vertices.push( vec4(0, 0, 0, 1) );
        colors.push( vec4(0, 0, 1, 1) );

        vertices.push( vec4(leng, 0, width, 1) );
        colors.push( vec4(0, 0, 1, 1) );

        vertices.push( vec4(leng, 0, 0, 1) );
        colors.push( vec4(0, 0, 1, 1) );

        this.count = 18;
    }

    draw(){
        gl.uniformMatrix4fv(RLoc, false, flatten(this.R));
        gl.uniformMatrix4fv(SLoc, false, flatten(this.S));
        gl.uniformMatrix4fv(TLoc, false, flatten(this.T));
        gl.drawArrays(gl.TRIANGLES, this.startId, this.count);
    }
}