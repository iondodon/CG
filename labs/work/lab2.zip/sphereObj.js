class Sphere {
    constructor(startId, radius, delta){
        this.startId = 0;
        this.count = 0;
    
        this.radius = 1;
        this.delta = 10;
    
        this.R = rotate(0, [0, 1, 0]);
        this.S = scalem(0.5, 0.5, 1.0);
        this.T = translate(0.0, 0.0, 0.0);;

        this.calculateSphere();
    }

    /**
     * @return {number}
     */
    X(theta, phi){
        let radius = this.radius;
        return radius * Math.sin(radians(theta)) * Math.cos(radians(phi));
    }

    /**
     * @return {number}
     */
    Y(theta, phi){
        let radius = this.radius;
        return radius * Math.sin(radians(theta)) * Math.sin(radians(phi));
    }

    /**
     * @return {number}
     */
    Z(theta){
        let radius = this.radius;
        return radius * Math.cos(radians(theta));
    }

    calculateSphere(){
        let delta = this.delta;

        for(let theta = 0; theta < 180; theta += delta){
            for (let phi = 0; phi < 360; phi += delta){
                vertices.push(vec4( this.X(theta, phi), this.Y(theta, phi), this.Z(theta), 1));
                colors.push(vec4(1, 0, 0, 1));

                vertices.push(vec4( this.X(theta+delta, phi), this.Y(theta+delta, phi), this.Z(theta+delta), 1));
                colors.push(vec4(1, 0, 0, 1));

                vertices.push(vec4( this.X(theta, phi+delta), this.Y(theta, phi+delta), this.Z(theta), 1));
                colors.push(vec4(1, 0, 0, 1));


                vertices.push(vec4( this.X(theta+delta, phi), this.Y(theta+delta, phi), this.Z(theta+delta), 1));
                colors.push(vec4(0, 1, 1, 1));

                vertices.push(vec4( this.X(theta, phi+delta), this.Y(theta, phi+delta), this.Z(theta), 1));
                colors.push(vec4(0, 1, 1, 1));

                vertices.push(vec4( this.X(theta+delta, phi+delta), this.Y(theta+delta, phi+delta), this.Z(theta+delta), 1));
                colors.push(vec4(0, 1, 1, 1));

                this.count += 6;
            }
        }
    }

    draw(){
        gl.uniformMatrix4fv(RLoc, false, flatten(this.R));
        gl.uniformMatrix4fv(SLoc, false, flatten(this.S));
        gl.uniformMatrix4fv(TLoc, false, flatten(this.T));
        gl.drawArrays(gl.TRIANGLES, this.startId, this.count);
    }
}